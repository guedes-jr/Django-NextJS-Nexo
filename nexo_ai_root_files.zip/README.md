# Arquivos de IA para a raiz do projeto NEXO

Este pacote contém os seguintes arquivos para uso na raiz da aplicação:

- .ai-system
- .ai-context
- .ai-agents
- .ai-prompts
- .ai-commands
- .ai-ignore
- .ai-treesitter

## Objetivo
Padronizar o uso de IA no desenvolvimento do projeto NEXO, mantendo:
- contexto do produto
- padrões técnicos
- papéis de agentes
- prompts reutilizáveis
- comandos de trabalho
- exclusões de contexto desnecessário

## Como usar
Coloque todos os arquivos na raiz do repositório.
Depois, ajuste o conteúdo conforme o projeto for evoluindo.
O ideal é atualizar:
- .ai-context quando o escopo mudar
- .ai-system quando as regras técnicas mudarem
- .ai-ignore quando surgirem novas pastas irrelevantes
- .ai-prompts conforme o time padronizar novos fluxos

## Observação
Os arquivos foram criados com base no plano da plataforma NEXO:
Django + PostgreSQL + Next.js + React Native.
